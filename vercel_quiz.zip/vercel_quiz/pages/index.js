import { useEffect, useState } from 'react';
import Link from 'next/link';

// Home page component. This largely mirrors the original Jinja2 template
// but uses React. It checks the current session via /api/session and
// conditionally renders guest vs logged-in options. The styling is
// intentionally minimal; feel free to import a CSS module or use
// Tailwind once you refine the design.

export default function Home() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    // Query the session API to see if a user is logged in. This
    // endpoint should return { logged_in: boolean, username?: string }.
    async function checkSession() {
      try {
        const res = await fetch('/api/session');
        const data = await res.json();
        if (data.logged_in) {
          setLoggedIn(true);
          setUsername(data.username || '');
        }
      } catch (err) {
        console.error('Failed to check session', err);
      }
    }
    checkSession();
  }, []);

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem', textAlign: 'center' }}>
      <h1>Welcome to the quiz!</h1>
      <p>{loggedIn ? `Logged in as: ${username}` : 'Play as a guest or log in to track your scores.'}</p>
      {/* Guest buttons */}
      {!loggedIn && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          <Link href="/play/guest" legacyBehavior><a style={buttonStyle}>Play as Guest</a></Link>
          <Link href="/history" legacyBehavior><a style={buttonStyle}>View Score History</a></Link>
          <Link href="/login" legacyBehavior><a style={buttonStyle}>Login</a></Link>
          <Link href="/howtoplay" legacyBehavior><a style={buttonStyle}>How to Play</a></Link>
          <Link href="/register" legacyBehavior><a style={buttonStyle}>Register</a></Link>
        </div>
      )}
      {/* Logged-in buttons */}
      {loggedIn && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          <Link href="/play" legacyBehavior><a style={buttonStyle}>Play</a></Link>
          <Link href="/settings" legacyBehavior><a style={buttonStyle}>Settings</a></Link>
          <Link href="/history" legacyBehavior><a style={buttonStyle}>Score History</a></Link>
          <button onClick={async () => {
            await fetch('/api/auth/logout', { method: 'POST' });
            setLoggedIn(false);
            setUsername('');
          }} style={{ ...buttonStyle, backgroundColor: '#dc3545' }}>Logout</button>
        </div>
      )}
    </div>
  );
}

// Simple inline styles reused for buttons
const buttonStyle = {
  display: 'block',
  padding: '0.5rem 1rem',
  textAlign: 'center',
  backgroundColor: '#007bff',
  color: '#fff',
  borderRadius: '6px',
  textDecoration: 'none',
  fontWeight: 'bold'
};