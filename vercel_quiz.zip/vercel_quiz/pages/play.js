import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// Play page for starting a quiz. This page fetches categories, lets the
// user select multiple categories, then choose the number of questions.
// Finally, it redirects to /quiz with query parameters for categories and limit.
export default function Play() {
  const [step, setStep] = useState(1);
  const [categories, setCategories] = useState([]);
  const [selected, setSelected] = useState([]);
  const [maxQuestions, setMaxQuestions] = useState(0);
  const [numQuestions, setNumQuestions] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  // Fetch categories on mount
  useEffect(() => {
    async function fetchCategories() {
      try {
        const res = await fetch('/api/categories');
        const data = await res.json();
        setCategories(data);
      } catch (err) {
        console.error('Error fetching categories', err);
      }
    }
    fetchCategories();
  }, []);

  const toggleCategory = (cat) => {
    setSelected((prev) => {
      if (prev.includes(cat)) {
        return prev.filter((c) => c !== cat);
      } else {
        return [...prev, cat];
      }
    });
  };

  const handleNext = async () => {
    if (selected.length === 0) {
      setError('Please select at least one category');
      return;
    }
    setError('');
    // Fetch total questions for selected categories
    try {
      const res = await fetch(`/api/quiz?categories=${selected.join(',')}`);
      const data = await res.json();
      setMaxQuestions(data.total);
      setNumQuestions('');
      setStep(2);
    } catch (err) {
      console.error('Failed to load question count', err);
    }
  };

  const handleStart = () => {
    // Validate number of questions
    const num = parseInt(numQuestions, 10);
    if (!num || num < 1) {
      setError('Please enter a valid number of questions');
      return;
    }
    if (num > maxQuestions) {
      setError(`Maximum available questions is ${maxQuestions}`);
      return;
    }
    setError('');
    // Redirect to quiz page with query params
    const query = new URLSearchParams({
      categories: selected.join(','),
      limit: num.toString(),
    });
    router.push(`/quiz?${query.toString()}`);
  };

  // Optionally start random 10; we ignore categories and just use limit=10
  const handleRandom10 = () => {
    // Use categories if selected; else no categories
    const query = new URLSearchParams({
      limit: '10',
      categories: selected.join(','),
    });
    router.push(`/quiz?${query.toString()}`);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem' }}>
      <h1>Start Quiz</h1>
      {step === 1 && (
        <div>
          <p>Select categories:</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center' }}>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => toggleCategory(cat)}
                style={{
                  padding: '0.5rem 1rem',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  backgroundColor: selected.includes(cat) ? '#007bff' : '#f0f0f0',
                  color: selected.includes(cat) ? '#fff' : '#000',
                  cursor: 'pointer',
                }}
              >
                {cat}
              </button>
            ))}
          </div>
          {error && <p style={{ color: 'red', marginTop: '1rem' }}>{error}</p>}
          <button onClick={handleNext} style={{ ...navButtonStyle, marginTop: '1rem' }}>Next</button>
        </div>
      )}
      {step === 2 && (
        <div>
          <p>Select number of questions (1–{maxQuestions}):</p>
          <input
            type="number"
            min="1"
            max={maxQuestions}
            value={numQuestions}
            onChange={(e) => setNumQuestions(e.target.value)}
            style={{ padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          />
          {error && <p style={{ color: 'red', marginTop: '1rem' }}>{error}</p>}
          <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
            <button onClick={() => setStep(1)} style={navButtonStyle}>Back</button>
            <button onClick={handleStart} style={navButtonStyle}>Start Quiz</button>
            <button onClick={handleRandom10} style={navButtonStyle}>Random 10</button>
          </div>
        </div>
      )}
    </div>
  );
}

const navButtonStyle = {
  padding: '0.5rem 1rem',
  borderRadius: '4px',
  border: 'none',
  backgroundColor: '#007bff',
  color: '#fff',
  cursor: 'pointer',
};