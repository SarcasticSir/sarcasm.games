// Static How to Play page. This page mirrors the original template's content.
export default function HowToPlay() {
  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '2rem' }}>
      <h1>How to Play</h1>
      <p>
        Select one or more categories, choose how many questions you want to answer, and then start the
        quiz. For each question, type your answer and press Enter or click Submit. If your answer is
        almost correct, you may get a second chance!
      </p>
      <p>
        Scores are recorded if you&apos;re logged in. You can view your history from the home page. Guest
        scores are not persisted.
      </p>
    </div>
  );
}