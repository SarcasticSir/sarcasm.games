import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// History page. Fetches the user's recent scores and displays them in a table.
export default function History() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    async function loadHistory() {
      try {
        const res = await fetch('/api/history');
        const data = await res.json();
        setHistory(data.history || []);
      } catch (err) {
        console.error('Error loading history', err);
      } finally {
        setLoading(false);
      }
    }
    loadHistory();
  }, []);

  if (loading) return <p>Loading history...</p>;

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '2rem' }}>
      <h1>Score History</h1>
      {history.length === 0 ? (
        <p>No scores recorded yet.</p>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th style={thStyle}>Score</th>
              <th style={thStyle}>Total Questions</th>
              <th style={thStyle}>Timestamp</th>
            </tr>
          </thead>
          <tbody>
            {history.map((row, idx) => (
              <tr key={idx} style={{ textAlign: 'center' }}>
                <td style={tdStyle}>{row.score}</td>
                <td style={tdStyle}>{row.total}</td>
                <td style={tdStyle}>{new Date(row.timestamp).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const thStyle = {
  border: '1px solid #ddd',
  padding: '0.5rem',
  backgroundColor: '#007bff',
  color: '#fff',
};
const tdStyle = {
  border: '1px solid #ddd',
  padding: '0.5rem',
};