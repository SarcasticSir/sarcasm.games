import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// Quiz page component. This page fetches quiz questions based on the
// query parameters (categories and limit) and handles the quiz flow.
export default function Quiz() {
  const router = useRouter();
  const { categories = '', limit } = router.query;
  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [almostTried, setAlmostTried] = useState({});
  const [correctlyAnswered, setCorrectlyAnswered] = useState([]);

  useEffect(() => {
    async function fetchQuiz() {
      if (!router.isReady) return;
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (categories) params.set('categories', categories);
        if (limit) params.set('limit', limit);
        const res = await fetch(`/api/quiz?${params.toString()}`);
        const data = await res.json();
        setQuestions(data.questions || []);
        setIndex(0);
        setScore(0);
        setAnswer('');
        setAlmostTried({});
        setCorrectlyAnswered([]);
      } catch (err) {
        console.error('Error loading quiz', err);
      } finally {
        setLoading(false);
      }
    }
    fetchQuiz();
  }, [router.isReady, categories, limit]);

  const currentQuestion = questions[index];

  // Helper: compute edit distance
  const levenshtein = (a, b) => {
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
    for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
    for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j - 1] + cost,
        );
      }
    }
    return matrix[a.length][b.length];
  };

  const isAlmostCorrect = (user, correct) => {
    const num1 = parseFloat(user);
    const num2 = parseFloat(correct);
    if (!isNaN(num1) && !isNaN(num2)) {
      const margin = Math.abs(num2 * 0.1);
      return Math.abs(num1 - num2) <= margin;
    }
    const dist = levenshtein(user.toLowerCase(), correct.toLowerCase());
    return (1 - dist / Math.max(user.length, correct.length)) >= 0.7;
  };

  const handleSubmit = async () => {
    if (!currentQuestion) return;
    const userAnswer = answer.trim();
    const correctAnswer = currentQuestion.answer.trim();
    if (!userAnswer) {
      setError('Please provide an answer');
      return;
    }
    setError('');
    // Check answer
    if (userAnswer.toLowerCase() === correctAnswer.toLowerCase()) {
      setScore((s) => s + 1);
      setCorrectlyAnswered((ids) => [...ids, currentQuestion.id]);
      goNext();
    } else {
      // Check almost correct
      if (!almostTried[currentQuestion.id] && isAlmostCorrect(userAnswer, correctAnswer)) {
        // Give another try
        setAlmostTried((prev) => ({ ...prev, [currentQuestion.id]: true }));
        alert('⚠️ Almost correct! Try once more.');
        return;
      } else {
        alert(`❌ Wrong! The correct answer was: ${correctAnswer}`);
        goNext();
      }
    }
  };

  const goNext = () => {
    setAnswer('');
    setIndex((i) => i + 1);
  };

  const finishQuiz = async () => {
    try {
      await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ score, total: questions.length, question_ids: correctlyAnswered }),
      });
    } catch (err) {
      console.error('Error submitting quiz', err);
    }
    alert(`You scored ${score} out of ${questions.length}!`);
    router.push('/history');
  };

  if (loading) {
    return <p>Loading quiz...</p>;
  }
  if (!questions.length) {
    return <p>No questions available.</p>;
  }
  if (index >= questions.length) {
    finishQuiz();
    return <p>Submitting score...</p>;
  }
  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem' }}>
      <h2>Question {index + 1} of {questions.length}</h2>
      <p style={{ whiteSpace: 'pre-wrap' }}>{currentQuestion.question}</p>
      {/* Media if present */}
      {currentQuestion.media && currentQuestion.media.endsWith('.mp3') && (
        <audio controls style={{ marginTop: '1rem' }}>
          <source src={`/static/${currentQuestion.media}`} type="audio/mpeg" />
        </audio>
      )}
      {currentQuestion.media && !currentQuestion.media.endsWith('.mp3') && (
        <img src={`/static/${currentQuestion.media}`} alt="Question Media" style={{ maxWidth: '100%', marginTop: '1rem' }} />
      )}
      <div style={{ marginTop: '1rem' }}>
        <input
          type="text"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Enter your answer"
          style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSubmit();
          }}
        />
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </div>
      <button onClick={handleSubmit} style={submitButtonStyle}>Submit</button>
    </div>
  );
}

const submitButtonStyle = {
  marginTop: '1rem',
  padding: '0.5rem 1rem',
  borderRadius: '4px',
  border: 'none',
  backgroundColor: '#007bff',
  color: '#fff',
  cursor: 'pointer',
};