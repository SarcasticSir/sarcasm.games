import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

// Settings page. Allows the user to delete score history or account.
export default function Settings() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [message, setMessage] = useState('');
  const router = useRouter();

  useEffect(() => {
    async function check() {
      try {
        const res = await fetch('/api/session');
        const data = await res.json();
        if (data.logged_in) {
          setLoggedIn(true);
          setUsername(data.username);
        }
      } catch (err) {
        console.error('Error checking session', err);
      }
    }
    check();
  }, []);

  if (!loggedIn) {
    return <p style={{ padding: '2rem' }}>You must be logged in to view this page.</p>;
  }

  const deleteHistory = async () => {
    setMessage('');
    try {
      const res = await fetch('/api/settings/delete_history', { method: 'POST' });
      const data = await res.json();
      setMessage(data.message || 'History deleted');
    } catch (err) {
      console.error('Error deleting history', err);
      setMessage('Failed to delete history');
    }
  };

  const deleteAccount = async () => {
    if (!confirm('Are you sure you want to delete your account? This cannot be undone.')) return;
    setMessage('');
    try {
      const res = await fetch('/api/settings/delete_account', { method: 'POST' });
      const data = await res.json();
      setMessage(data.message || 'Account deleted');
      // Redirect to home after deletion
      router.push('/');
    } catch (err) {
      console.error('Error deleting account', err);
      setMessage('Failed to delete account');
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem' }}>
      <h1>Settings</h1>
      <p>Logged in as: {username}</p>
      {message && <p style={{ color: 'green' }}>{message}</p>}
      <button onClick={deleteHistory} style={btnStyle}>Delete Score History</button>
      <button onClick={deleteAccount} style={{ ...btnStyle, backgroundColor: '#dc3545' }}>Delete Account</button>
    </div>
  );
}

const btnStyle = {
  display: 'block',
  width: '100%',
  padding: '0.5rem',
  marginBottom: '1rem',
  borderRadius: '4px',
  border: 'none',
  backgroundColor: '#007bff',
  color: '#fff',
  cursor: 'pointer',
};