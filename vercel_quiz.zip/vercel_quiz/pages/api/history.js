import pool from '../../db.js';
import cookie from 'cookie';

// History API. Returns recent scores for the logged-in user. If not logged in,
// returns a placeholder guest score if available (guest mode is not persisted).
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const cookies = cookie.parse(req.headers.cookie || '');
    const userId = cookies.user_id;
    if (!userId) {
      // No user logged in. Return empty history.
      res.status(200).json({ history: [] });
      return;
    }
    const result = await pool.query(
      'SELECT score, total_questions, timestamp FROM user_score WHERE user_id = $1 ORDER BY timestamp DESC LIMIT 10',
      [userId]
    );
    const history = result.rows.map((r) => ({ score: r.score, total: r.total_questions, timestamp: r.timestamp }));
    res.status(200).json({ history });
  } catch (err) {
    console.error('Error fetching history:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}