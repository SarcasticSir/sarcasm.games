import pool from '../../db.js';
import cookie from 'cookie';

// Session API route. Returns whether the user is logged in and the username.
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const cookies = cookie.parse(req.headers.cookie || '');
    const userId = cookies.user_id;
    if (!userId) {
      res.status(200).json({ logged_in: false });
      return;
    }
    // Look up the user to get the username; ignore errors if user id not found
    try {
      const result = await pool.query('SELECT username FROM "user" WHERE id = $1', [userId]);
      if (result.rows.length > 0) {
        res.status(200).json({ logged_in: true, username: result.rows[0].username });
      } else {
        res.status(200).json({ logged_in: false });
      }
    } catch (e) {
      res.status(200).json({ logged_in: false });
    }
  } catch (err) {
    console.error('Error checking session:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}