import pool from '../../db.js';
import cookie from 'cookie';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const { score = 0, total = 0, question_ids = [] } = req.body || {};
    // Parse cookies to see if a user_id is present
    const cookies = cookie.parse(req.headers.cookie || '');
    const userId = cookies.user_id;
    if (userId) {
      // Store score for logged-in user. Note: the user_score table should exist with
      // columns (user_id int, score int, total_questions int, timestamp default now())
      await pool.query(
        'INSERT INTO user_score (user_id, score, total_questions) VALUES ($1, $2, $3)',
        [userId, score, total]
      );
      // Also record answered questions if question_ids provided
      if (Array.isArray(question_ids) && question_ids.length > 0) {
        const insertPromises = question_ids.map(id =>
          pool.query(
            'INSERT INTO user_answered_question (user_id, question_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [userId, id]
          )
        );
        await Promise.all(insertPromises);
      }
    }
    res.status(200).json({ message: 'Score recorded' });
  } catch (err) {
    console.error('Failed to record score:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}