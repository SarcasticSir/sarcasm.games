import pool from '../../db.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  const { categories = '', limit } = req.query;
  // Parse categories from query string
  let categoryList = [];
  if (typeof categories === 'string' && categories.trim()) {
    categoryList = categories.split(',').map(c => c.trim()).filter(Boolean);
  }
  try {
    // Build parameterized query
    let whereClause = '';
    let params = [];
    if (categoryList.length > 0) {
      whereClause = ' WHERE category = ANY($1)';
      params.push(categoryList);
    }
    // Get total available questions for these categories
    const totalRes = await pool.query(
      `SELECT COUNT(*) AS total FROM question${whereClause}`,
      params
    );
    const total = parseInt(totalRes.rows[0]?.total || '0', 10);
    // Build query for random questions if limit provided
    let questions = [];
    if (limit) {
      const num = parseInt(limit, 10);
      if (!isNaN(num) && num > 0) {
        const qRes = await pool.query(
          `SELECT id, text, answer, category, media FROM question${whereClause} ORDER BY RANDOM() LIMIT $${params.length + 1}`,
          [...params, num]
        );
        questions = qRes.rows.map(r => ({
          id: r.id,
          question: r.text,
          answer: r.answer,
          category: r.category,
          media: r.media || null,
        }));
      }
    }
    res.status(200).json({ total, questions });
  } catch (err) {
    console.error('Failed to fetch quiz questions:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}