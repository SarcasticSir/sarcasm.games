import pool from '../../../db.js';
import cookie from 'cookie';

// API to delete score history for the logged-in user.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const cookies = cookie.parse(req.headers.cookie || '');
    const userId = cookies.user_id;
    if (!userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }
    await pool.query('DELETE FROM user_score WHERE user_id = $1', [userId]);
    res.status(200).json({ message: 'Score history deleted' });
  } catch (err) {
    console.error('Error deleting history:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}