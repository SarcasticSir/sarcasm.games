import pool from '../../../db.js';
import cookie from 'cookie';

// API to delete the current user account and associated data.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const cookies = cookie.parse(req.headers.cookie || '');
    const userId = cookies.user_id;
    if (!userId) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }
    // Delete user-related data in proper order: user_score, user_answered_question, then user
    await pool.query('DELETE FROM user_score WHERE user_id = $1', [userId]);
    await pool.query('DELETE FROM user_answered_question WHERE user_id = $1', [userId]);
    await pool.query('DELETE FROM "user" WHERE id = $1', [userId]);
    // Clear cookie
    res.setHeader('Set-Cookie', cookie.serialize('user_id', '', {
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 0,
    }));
    res.status(200).json({ message: 'Account deleted' });
  } catch (err) {
    console.error('Error deleting account:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}