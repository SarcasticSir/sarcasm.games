import pool from '../../../db.js';
import bcrypt from 'bcryptjs';
import cookie from 'cookie';

// Login API route. Accepts POST with JSON { username, password, remember? }.
// If credentials are valid, set an HTTP-only cookie "user_id" and return user info.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const { username, password, remember = false } = req.body || {};
    if (!username || !password) {
      res.status(400).json({ message: 'Missing username or password' });
      return;
    }
    // Look up the user by username
    const result = await pool.query('SELECT id, username, password FROM "user" WHERE username = $1', [username]);
    if (result.rows.length === 0) {
      res.status(401).json({ message: 'Invalid username or password' });
      return;
    }
    const user = result.rows[0];
    // Compare the provided password to the stored hash
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      res.status(401).json({ message: 'Invalid username or password' });
      return;
    }
    // Set user_id cookie. Use a long expiration if remember=true; otherwise session cookie.
    const cookieOptions = {
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
    };
    if (remember) {
      // 30 days
      cookieOptions.maxAge = 60 * 60 * 24 * 30;
    }
    res.setHeader('Set-Cookie', cookie.serialize('user_id', String(user.id), cookieOptions));
    res.status(200).json({ message: 'Login successful', username: user.username });
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}