import pool from '../../../db.js';
import bcrypt from 'bcryptjs';
import cookie from 'cookie';

// User registration API. Accepts POST with JSON { username, password, email? }.
// Creates a new user if the username is not taken. Hashes the password using bcrypt.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    const { username, password, email } = req.body || {};
    if (!username || !password) {
      res.status(400).json({ message: 'Missing username or password' });
      return;
    }
    // Optional validation: limit username length
    if (username.length > 20) {
      res.status(400).json({ message: 'Username must be 20 characters or fewer' });
      return;
    }
    // Check if the username already exists
    const exists = await pool.query('SELECT id FROM "user" WHERE username = $1', [username]);
    if (exists.rows.length > 0) {
      res.status(400).json({ message: 'Username already exists' });
      return;
    }
    // Hash the password
    const hashed = await bcrypt.hash(password, 10);
    // Insert the new user
    const insert = await pool.query(
      'INSERT INTO "user" (username, password, email) VALUES ($1, $2, $3) RETURNING id, username',
      [username, hashed, email || null]
    );
    const newUser = insert.rows[0];
    // Set cookie
    res.setHeader('Set-Cookie', cookie.serialize('user_id', String(newUser.id), {
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 30,
    }));
    res.status(200).json({ message: 'User registered successfully', username: newUser.username });
  } catch (err) {
    console.error('Error during registration:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}