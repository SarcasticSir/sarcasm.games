import cookie from 'cookie';

// Logout API route. Simply clears the user_id cookie.
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  // Clear the cookie by setting an expired cookie
  res.setHeader('Set-Cookie', cookie.serialize('user_id', '', {
    httpOnly: true,
    path: '/',
    sameSite: 'lax',
    maxAge: 0,
  }));
  res.status(200).json({ message: 'Logged out successfully' });
}