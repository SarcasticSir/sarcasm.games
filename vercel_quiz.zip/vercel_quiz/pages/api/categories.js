import pool from '../../db.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ message: 'Method not allowed' });
    return;
  }
  try {
    // Select distinct categories from the question table. If no questions exist,
    // this will return an empty array.
    const result = await pool.query('SELECT DISTINCT category FROM question');
    const categories = result.rows.map(row => row.category);
    res.status(200).json(categories);
  } catch (err) {
    console.error('Failed to fetch categories:', err);
    res.status(500).json({ message: 'Internal error' });
  }
}