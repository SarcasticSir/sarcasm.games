import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

// Login page component. Displays a form for username and password.
// On submit, sends POST request to /api/auth/login. If successful,
// redirects to home.
export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, remember }),
      });
      const data = await res.json();
      if (res.ok) {
        // redirect to home
        router.push('/');
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      console.error('Login error', err);
      setError('Login error');
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto', padding: '2rem' }}>
      <h1>Login</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label>Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
            required
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc' }}
            required
          />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            {' '}Remember me
          </label>
        </div>
        <button type="submit" style={{ ...buttonStyle }}>Login</button>
      </form>
      <p style={{ marginTop: '1rem' }}>Don&apos;t have an account? <Link href="/register">Register</Link></p>
    </div>
  );
}

const buttonStyle = {
  display: 'block',
  width: '100%',
  padding: '0.5rem',
  backgroundColor: '#007bff',
  color: '#fff',
  borderRadius: '4px',
  border: 'none',
  fontWeight: 'bold',
  cursor: 'pointer',
};