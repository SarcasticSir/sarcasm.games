// Simple database helper using Vercel Postgres. This module wraps the
// @vercel/postgres client into a pool. You can adjust the connection
// string via the POSTGRES_URL environment variable. For local
// development, you might set POSTGRES_URL in a .env file.

import { Pool } from '@vercel/postgres';

const connectionString = process.env.POSTGRES_URL;

// Create a single shared pool instance. The pool will lazily
// establish connections on demand.
const pool = new Pool({ connectionString });

export default pool;